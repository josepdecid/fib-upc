%% Exercici 6
% Sensible a les condicions inicials
r = 1:10;
p = poly(r);
g = p;
g(2) = g(2) + 1/(2^13);
roots(p)
roots(g)