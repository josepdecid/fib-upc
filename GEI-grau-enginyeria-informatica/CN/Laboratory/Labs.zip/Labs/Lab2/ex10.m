%% Exercici 10
for x = 1:18
   valorExacte = exp(x);
   n = 0;
   while 1
       valorAprox = aproximacioExp(x, n)
       if  abs(valorExacte - valorAprox) <= 0.5*(10^-8)
           break
       end
       n = n + 1;
   end
   valorExacte
end
