%% Exercici 9
taula = zeros(1, 20);
taula(1) = 1;
aux = 1;
for k = 2:20
    aux = aux /(k-1);
    taula(k) = taula(k-1) + aux;
end
taula = taula'
exp(1)
abs(exp(1) - taula(end))