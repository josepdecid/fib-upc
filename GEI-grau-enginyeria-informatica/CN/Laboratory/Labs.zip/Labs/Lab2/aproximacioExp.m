function [ suma ] = aproximacioExp( x, n, tol )
% C�lcul de e^x mitjan�ant una aproximaci� fent �s del polinomi de Taylor
% en x = 0.
    aux = 1;
    suma = 1;
    k = 1;
    era = 1;
    while k < n && era > tol
       aux = aux * x/k;
       suma = suma + aux;
       era = abs(exp(x) - suma);
       k = k + 1;
    end
    disp('iteracions '), disp(k);
    disp('error '), disp(era);
end