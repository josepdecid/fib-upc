%% Exercici 8
% Recurr�ncies estables i inestables
%% Gr�fiques
F = @(x, n) (x.^n) .* exp(x - 1);
t = 0:0.01:1;
subplot(321), plot(t, F(t, 1)), title('n = 1');
subplot(322), plot(t, F(t, 5)), title('n = 5');
subplot(323), plot(t, F(t, 10)), title('n = 10');
subplot(324), plot(t, F(t, 15)), title('n = 15');
subplot(325), plot(t, F(t, 24)), title('n = 24');
subplot(326), plot(t, F(t, 30)), title('n = 30');
%% Recurr�ncia Endavant
% El valor de n fa propagar l'error com�s en el c�lcul de la iteraci�
% anterior
If = zeros(1, 50);
If(1) = 1/exp(1);
for k = 2:50
   If(k) = 1 - k*If(k - 1); 
end
%% Recurr�ncia enrere
Ib = zeros(1, 50);
Ib(50) = eps();
for k = 50:-1:2
   Ib(k-1) = (1 - Ib(k))/k; 
end
%% Valor exacte
Ie = zeros(1, 50);
for k = 1:50
    Ie(k) = integral(@(x)F(x, k), 0, 1);
end
%% Errors absoluts
[abs(If - Ie); abs(Ib - Ie)]'
[If;Ib;Ie]';