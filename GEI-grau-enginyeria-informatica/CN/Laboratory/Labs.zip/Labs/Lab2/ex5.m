%% Exercici 5
% P�rdua de xifres significatives
f = @(x) sqrt((x.^2) + 1) - 1;
g = @(x)(x.^2) ./ (sqrt((x.^2) + 1) + 1);
n = 0:15;
t = 8 .^(-n);
y1 = f(t);
y2 = g(t);
[n; y1; y2]'
%{
Els resultats de f no s�n de fiar. Aix� �s degut a que f �s un algorisme de
cancel�laci�. En realitat el que fa �s restar (1 + c) - 1 on c << 1. Per
tant �s per aix� que arribat a un ser valor de n f retorna 0, hem perdut
xifres significatives. De fet les hem perdut totes. En canvi g si que t�
encara certa informaci� per els mateixos valors de n
%}