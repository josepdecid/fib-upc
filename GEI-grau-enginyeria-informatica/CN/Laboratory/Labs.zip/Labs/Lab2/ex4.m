%% Exercici 4
y = @(x1, x2, x3) x1*(x2^2)/sqrt(x3);
x1 = 2;
eA1 = 0.1;
x2 = 3;
eA2 = 0.2;
x3 = 1;
eA3 = 0.1;
errorAbsProp = abs((x2^2)/sqrt(x3)) * eA1 + abs(2*x2*x1/sqrt(x3)) * eA2 + ...
    abs(x1*(x2^2)/(2*sqrt(x3))) * eA3