%% Exercici 11
f = 1/exp(5.5);
fAprox = 1/aproximacioExp(5.5, 25, 5e-13);

fAprox
f
