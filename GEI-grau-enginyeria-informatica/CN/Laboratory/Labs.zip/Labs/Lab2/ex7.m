%% Exercici 7
% Sensible a les condicions inicials
%{
Forma 1
syms x y 
eq1 = 2*x - 4*y == 1;
eq2 = -3*x + 6.001*y == 2;
[A,B] = equationsToMatrix([eq1, eq2], [x, y]);
X = vpa(linsolve(A,B))

%%
eq2 = -2.998*x + 6.001*y == 2;
[A,B] = equationsToMatrix([eq1, eq2], [x, y]);
X = vpa(linsolve(A,B))
%}

% Forma 2
A = [2 , -4;-2.998, 6.001];
B = [1; 2];
X = A\B
%%
A(2, 2) = 6;
X = A\B