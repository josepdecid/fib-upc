%% Exercici 3
x = sqrt(3);
xAprox = 1.7321;
f = @(x) 1/(x + 2)^4;
g = @(x) 97 - 56*x;
df = @(x) -4/(2 + x)^5;
dg = @(x) -56;
fPropF = abs(df(xAprox))
fPropG = abs(dg(xAprox))
eAPropF = abs(df(xAprox)) * abs(x - xAprox)
eAPropG = abs(dg(xAprox)) * abs(x - xAprox)