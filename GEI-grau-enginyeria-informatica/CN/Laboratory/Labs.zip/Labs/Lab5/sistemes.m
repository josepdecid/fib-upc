%% Sistemes lineals
A = [1, 2, 0; -1, -3, 5; 0, 0, -100];
b = [3; 1; -100];
x = A\b % Resoluci� sistemes