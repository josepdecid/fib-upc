function [ sol ] = newton2Vars( F1, F2, x0, tol, iter, ... 
    dF1x, dF1y, dF2x, dF2y)

    x = x0(1);
    y = x0(2);
    k = 0;
    F = [F1(x, y); F2(x, y)];
    DF = [dF1x(x, y), dF1y(x, y); dF2x(x, y), dF2y(x, y)];
    tolf = norm(F);
    tolx = norm([x; y]);
    err = max(tolf, tolx);
    taula = [k, x, y, tolf, tolx];
    while err > tol && k < iter
        prev = [x; y];
        z = -DF\F;
        x = x + z(1);
        y = y + z(2);
        F = [F1(x, y); F2(x, y)];
        DF = [dF1x(x, y), dF1y(x, y); dF2x(x, y), dF2y(x, y)];
        tolx = norm([x; y] - prev);
        tolf = norm(F);
        err = max(tolx, tolf);
        k = k + 1;
        taula = [taula;k, x, y, tolf, tolx];
    end
    sol = [x; y];
    disp('  k       x       y       F(x)    tolx');
    disp(taula);
end
