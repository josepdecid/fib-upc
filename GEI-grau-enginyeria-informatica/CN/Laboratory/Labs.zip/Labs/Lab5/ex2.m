%% M�tode de punt fix per dues variables
%% Gr�fic funci� de dues variables
F1 = @(x, y) x - sin(x + y);
F2 = @(x, y) y - cos(x-y);
fimplicit(F1, [0, 2, 0, 2])
hold on
fimplicit(F2, [0, 2,0 , 2])
hold off
%% Funcio iterativa
G1 = @(x, y) sin(x + y);
G2 = @(x, y) cos(x - y);
x0 = [1; 1];
tol = 0.0000001;
iter = 16;
x = x0(1);
y = x0(2);
DG = [cos(x + y), cos(x + y); -sin(x - y), sin(x - y)];
if norm(DG, 2) < 1
    arrels = puntFix2Vars(F1, F2, G1, G2, x0, tol, iter);
else
    disp('M�tode Divergent');
end