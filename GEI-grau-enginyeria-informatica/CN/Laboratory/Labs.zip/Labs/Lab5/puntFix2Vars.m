function [ sol ] = puntFix2Vars( F1, F2, G1, G2, x0, tol, iter )

    x = x0(1);
    y = x0(2);
    k = 0;
    F = [F1(x, y); F2(x, y)];
    tolf = norm(F);
    tolx = norm([x; y]);
    err = max(tolf, tolx);
    taula = [k, x, y, tolf, tolx];
    while err > tol && k < iter
        prev = [x; y];
        x = G1(x, y);
        y = G2(x, y);
        F = [F1(x, y); F2(x, y)];
        tolf = norm(F);
        tolx = norm([x; y] - prev);
        err = max(tolf, tolx);
        k = k + 1;
        taula = [taula; k, x, y, tolf, tolx];
    end
    sol = [x; y];
    disp('  k       x       y       F(x)    tolx');
    disp(taula);
end

