%% Exercici 3
%% Apartat a). Gr�fica amb les equacions del sistema
F1 = @(x, y) x.^2 - y - 1;
F2 = @(x, y) (x - 2).^2 + (y - 0.5).^2 - 1;
fimplicit(F1, [0, 2, 0, 2]);
hold on;
fimplicit(F2, [0, 2, 0, 2]);
hold off;
x0 = [1.5; 1.4];
%% Arrel exacte
F = @(x) [x(1)^2 - x(2) - 1; (x(1) - 2)^2 + (x(2) - 0.5)^2 - 1];
solucioExacte = fsolve(F, x0)
%% Apartat b). 5 iterats per Newton
iter = 5;
tol = eps(); % Assegurar parar per iteracions
dF1x = @(x, y) 2*x;
dF1y = @(x, y) -1;
dF2x = @(x, y) 2*x - 4;
dF2y = @(x, y) 2*x - 1;
solucio = newton2Vars(F1, F2, x0, tol, iter, dF1x, dF1y, dF2x, dF2y);
%% Apartat c). 5 iterats per iteraci� simple
G1 = @(x, y) (y + 1)^(1/2);
G2 = @(x, y) x^2 - 4*x + y^2 + 3.25;
x = x0(1);
y = x0(2);
DG = [0, 1/(2*(y + 1)^(1/2)); 2*x - 4, 2*y];
if norm(DG) < 1
    solucio = puntFix2Vars(F1, F2, G1, G2, x0, tol, iter);
else
    disp('M�tode divergent');
end
%% Apartat d). Estudi de la converg�ncia
x = -2:0.05:2;
y = -2:0.05:2;
[X, Y] = meshgrid(x, y);
Aux = @(x, y) norm([0, 1/(2*(y + 1)^(1/2)); 2*x - 4, 2*y]);
z = zeros(size(X));
for i = 1:size(X, 1)
    for j = 1:size(X, 2)
        z(i,j) = Aux(X(i,j), Y(i,j));
    end
end
plot3(X, Y, z, solucioExacte(1), solucioExacte(2), Aux(solucioExacte(1), solucioExacte(2)), 'k*', ...
    X, Y, ones(size(X)), X, Y, -ones(size(X)));

