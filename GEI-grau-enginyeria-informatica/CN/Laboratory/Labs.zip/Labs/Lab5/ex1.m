%% M�tode de Newton per dues variables (Exercici 11)
%% Gr�fic funci� de dues variables
F1 = @(x, y) x - sin(x + y);
F2 = @(x, y) y - cos(x-y);
%x = 0:0.125:2;
%y = 0:0.125:2;
%[X, Y] = meshgrid(x, y);
%Z1 = F1(X, Y);
%Z2 = F2(X, Y);
fimplicit(F1, [0, 2, 0, 2])
hold on
fimplicit(F2, [0, 2,0 , 2])
hold off
%% M�tode de Newton
tol = 0.0000001;
iter = 10;
x0 = [1; 1];
dF1x = @(x, y) 1 - cos(x + y);
dF1y = @(x, y) -cos(x + y);
dF2x = @(x, y) sin(x - y);
dF2y = @(x, y) 1 - sin(x - y);
arrels = newton2Vars(F1, F2, x0, tol, iter, ...
    dF1x, dF1y, dF2x, dF2y);