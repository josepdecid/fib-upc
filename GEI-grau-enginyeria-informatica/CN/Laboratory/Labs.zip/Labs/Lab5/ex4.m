%% Exercici 4
%% Gr�fica per trobar un punt proper a la soluci�.
F1 = @(x, y) 42.25*x.^2 + 27.885*x - 0.749*y.^2 - 2.54*y - 2.466;
F2 = @(x, y) -0.52*x - 0.0192 + 0.00359*y.^2 + 0.00356*y;
fimplicit(F1, [-0.5, 3, -20, 20]);
hold on;
fimplicit(F2, [-0.5, 3, -20, 20]);
hold off;
G1 = @(x, y) 42.25*x.^2 + 27.885*x - 0.749*y.^2 - 2.54*y - 2.466 + x;
G2 = @(x, y)  -0.52*x - 0.0192 + 0.00359*y.^2 + 0.00356*y + y;
%dF1x = @(x, y) 2*42.25*x + 27.885;
%dF1y = @(x, y) 2*0.749*y - 2.54;
%dF2x = @(x, y) -0.52;
%dF2y = @(x, y) 2*0.00359*y + 0.00356;
%% Arrel exacte
x0 = [1.5, -15]
F = @(x) [cos(x(1)) - exp(x(2)); sin(x(1)*x(2)) - 1/2];
solucioExacte = fsolve(F, x0)
%% Punt inicial 1
x0 = [-0.01; 0.01];
iter = 15;
tol = eps();
x = x0(1);
y = x0(2);
DG = [(169*x)/2 + 5777/200, - (749*y)/500 - 127/50; -13/25, (359*y)/50000 + 25089/25000];
if norm(DG) < 1
    solucio = puntFix2Vars(F1, F2, G1, G2, x0, tol, iter);
else
    disp('Metode divergent');
end
%solucio = newton2Vars(F1, F2, x0, tol, iter, dF1x, dF1y, dF2x, dF2y);
%% Punt inicial 2
x0 = [0.3; 0.25];
x = x0(1);
y = x0(2);
DG = [(169*x)/2 + 5777/200, - (749*y)/500 - 127/50; -13/25, (359*y)/50000 + 25089/25000];
if norm(DG) < 1
    solucio = puntFix2Vars(F1, F2, G1, G2, x0, tol, iter);
else
    disp('Metode divergent');
end
%solucio = newton2Vars(F1, F2, x0, tol, iter, dF1x, dF1y, dF2x, dF2y);
%% Estudi converg�ncia
x = -0.5:0.05:3;
y = -20:0.05:20;
[X, Y] = meshgrid(x, y);
Aux = @(x, y) norm([(169*x)/2 + 5777/200, - (749*y)/500 - 127/50; -13/25, (359*y)/50000 + 25089/25000]);
z = zeros(size(X));
for i = 1:size(X, 1)
    for j = 1:size(X, 2)
        z(i,j) = Aux(X(i,j), Y(i,j));
    end
end
plot3(X, Y, z, solucioExacte(1), solucioExacte(2), Aux(solucioExacte(1), solucioExacte(2)), 'k*', ...
    X, Y, ones(size(X)), X, Y, -ones(size(X)));
