%% Exemple de normes vectorials i matricials
v = [1, 2, 3, 4, -5, -6, -7, 8, 9, 10];
norm(v) % Norma-2
norm(v, 2)
norm(v, 1) % Norma-1
norm(v, 'inf')
%%
A = [1, 2, 0; -1, -3, 5; 0, 0, -100];
norm(A, 1);
norm(A, 'inf');
norm(A, 'fro')
% sum(sum(abs(A.^2))
% sqrt(ans)
eig(A)
eig(A'*A)
sqrt(eig(A'*A))
