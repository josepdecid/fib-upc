%% Exercici 5
F1 = @(x, y) cos(x) - exp(y);
F2 = @(x, y) sin(x*y) - 1/2;
fimplicit(F1, [-5, 5, -5, 5]);
hold on;
fimplicit(F2, [-5, 5, -5, 5]);
hold off;
%% Existeix una soluci� prop del punt [-1, 0]
x0 = [-1; 0];
%% Soluci� exacte
F = @(x) [cos(x(1)) - exp(x(2)); sin(x(1)*x(2)) - 1/2];
solucioExacte = fsolve(F, x0)
%% M�tode de Newton
tol = 0.000001;
iter = 20;
dF1x = @(x, y) - sin(x);
dF1y = @(x, y) - exp(y);
dF2x = @(x, y) cos(x*y)*y;
dF2y = @(x, y) cos(x*y)*x;
solucio = newton2Vars(F1, F2, x0, tol, iter, dF1x, dF1y, dF2x, dF2y)
%% M�tode d'iteracio simple
tol = 0.000001;
iter = 20;
x = x0(1);
y = x0(2);
G1 = @(x, y) cos(x) - exp(y) + x;
G2 = @(x, y) sin(x*y) - 1/2 + y;
DG = [-sin(x) + 1, -exp(y); cos(x*y)*y, cos(x*y)*x + 1];
if norm(DG) < 1
    solucio = puntFix2Vars(F1, F2, G1, G2, x0, tol, iter)
else
    disp('M�tode divergent');
end
%% Estudi converg�ncia
x = -2:0.05:2;
y = -2:0.05:2;
[X, Y] = meshgrid(x, y);
Aux = @(x, y) norm([-sin(x) + 1, -exp(y); cos(x*y)*y, cos(x*y)*x + 1]);
z = zeros(size(X));
for i = 1:size(X, 1)
    for j = 1:size(X, 2)
        z(i,j) = Aux(X(i,j), Y(i,j));
    end
end
plot3(X, Y, z, solucioExacte(1), solucioExacte(2), Aux(solucioExacte(1), solucioExacte(2)), 'k*', ...
    X, Y, ones(size(X)), X, Y, -ones(size(X)));

