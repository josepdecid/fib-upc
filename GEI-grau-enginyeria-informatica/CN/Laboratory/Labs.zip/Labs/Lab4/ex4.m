%% Exercici 4
% Equaci� x + ln (x) = 0
%Gr�fica
t = 0.1:0.01:1;
f = @(x) x + log(x);
plot(t, f(t), t, zeros(size(t))), grid;
%% Valor real de l'arrel
arrelExacte = fzero(f, 0.5)
%% M�tode iteratiu 1
g1 = @(x) -log(x);
dg1 = @(x) -1./x;
tol = 0.0005;
x0 = 0.5;
if abs(dg1(x0)) < 1
    alpha = metodePuntFix(f, g1, x0, tol, 50)
else
    disp('M�tode divergent');
end
%% M�tode iteratiu 2
g2 = @(x) exp(-x);
dg2 = @(x) -exp(-x);
tol = 0.0005;
x0 = 0.5;
if abs(dg2(x0)) < 1
    alpha = metodePuntFix(f, g2, x0, tol, 20)
else
    disp('M�tode divergent');
end
%% M�tode iteratiu 3
g3 = @(x) (x + exp(-x))/2;
dg3 = @(x) (1 - exp(-x))/2;
tol = 0.0005;
x0 = 0.5;
if abs(dg3(x0)) < 1
    alpha = metodePuntFix(f, g3, x0, tol, 50)
else
    disp('M�tode divergent');
end
%% Estudi de la converg�ncia
subplot(221);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg1(t), arrelExacte, dg1(arrelExacte), '*'), grid, title('M�tode 1');
subplot(222);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg2(t), arrelExacte, dg2(arrelExacte), '*'), grid, title('M�tode 2');
subplot(223);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg3(t), arrelExacte, dg3(arrelExacte), '*'), grid, title('M�tode 3');