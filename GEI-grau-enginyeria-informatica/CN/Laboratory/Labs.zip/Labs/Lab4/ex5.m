%% Exercici 5
% M�tode iteratiu 1
g1 = @(x) (8*x - x^2)/4;
dg1 = @(x) (8 - 2*x)/4;
tol = 0.0005;
x0 = 3;
if abs(dg1(x0)) < 1
    alpha = metodePuntFix(g1, x0, tol, 6)
else
    disp('M�tode divergent');
end
%% M�tode iteratiu 2
g2 = @(x) (x^2 - 4)/3;
dg2 = @(x) 2*x/3;
tol = 0.0005;
x0 = 0.5;
if abs(dg2(x0)) < 1
    alpha = metodePuntFix(g2, x0, tol, 20)
else
    disp('M�tode divergent');
end
%% M�tode iteratiu 3
g3 = @(x) (3*x + 4).^(1/2);
dg3 = @(x) 3./(2*(3*x + 4).^(1/2));
tol = 0.0005;
x0 = 0.5;
if abs(dg3(x0)) < 1
    alpha = metodePuntFix(g3, x0, tol, 50)
else
    disp('M�tode divergent');
end
%% Estudi de la converg�ncia
subplot(221);
arrelExacte = 4;
t = 0:0.05:8;
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg1(t), arrelExacte, dg1(arrelExacte), '*'), grid, title('M�tode 1');
subplot(222);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg2(t), arrelExacte, dg2(arrelExacte), '*'), grid, title('M�tode 2');
subplot(223);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg3(t), arrelExacte, dg3(arrelExacte), '*'), grid, title('M�tode 3');