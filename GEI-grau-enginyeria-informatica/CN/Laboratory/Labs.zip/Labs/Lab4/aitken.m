function [ alpha ] = aitken(f, Xn, tol, M )
% Acceleraci� de la converg�ncia mitjan�ant Aitken
% f �s la funci� inicial de la que volem aproximar el zero
% Xn �s la successi� generada amb el m�tode de punt fix que surt de f
% i la qual t� converg�ncia lineal
% tol �s la cota superior de l'error absolut
% M �s el m�xim d'iteracions permeses
    k = 1;
    x0 = Xn(1); x1 = Xn(2); x2 = Xn(3);
    xAitken = x2 - (x2 - x1)^2/(x2 - 2*x1 + x0);
    tolx = abs(xAitken);
    tolf = abs(f(xAitken));
    err = max(tolx, tolf);
    taula = [k, xAitken, f(xAitken), tolx];
    i = 2;
    while (err > tol && k < M) && i+2 <= length(Xn)
        xPrev = xAitken;
        x0 = Xn(i);
        x1 = Xn(i+1);
        x2 = Xn(i+2);
        k = k + 1;
        xAitken = x2 - (x2 - x1)^2/(x2 - 2*x1 + x0);
        tolx = abs(xAitken - xPrev);
        tolf = abs(f(xAitken));
        err = max(tolx, tolf);
        taula = [taula;k, xAitken, f(xAitken), tolx];
        i = i + 1;
    end
    disp('          k       xAitken      f(x)        tolx');
    fprintf('%2.0f \t %10.8f \t %10.6e \t %10.6e\n', taula')
    alpha = xAitken;
    
end

