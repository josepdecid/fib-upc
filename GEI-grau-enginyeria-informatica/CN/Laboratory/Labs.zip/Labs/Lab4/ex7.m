%% Exercici 7
%Gr�fica
t = -2:0.05:2;
f = @(x) exp(x).*x - 1;
plot(t, f(t), t, zeros(size(t))), grid;
%% Valor real de l'arrel
alphaExacte = fzero(f, 0.5)
%% M�tode iteratiu
g = @(x) exp(-x);
dg = @(x) -exp(-x);
tol = 0.0000005;
x0 = 0.5;
if abs(dg(x0)) < 1
    [alpha, Xn] = metodePuntFix(f, g, x0, tol, 100);
    alpha
else
    disp('M�tode divergent');
end
%% M�tode d'Aitken
tol = 0.0000005;
if abs(dg(x0)) < 1
    alpha = aitken(f, Xn, tol, 100)
else
    disp('M�tode divergent');
end
%% M�tode d'Steffensen
tol = 0.0000005;
x0 = Xn(1); x1 = Xn(2); x2 = Xn(3);
x0 = x0 - (x1 - x0)^2/(x2 - 2*x1 + x0);
if abs(dg(x0)) < 1
    alpha = steffensen(f, g, x0, tol, 100)
else
    disp('M�tode divergent');
end