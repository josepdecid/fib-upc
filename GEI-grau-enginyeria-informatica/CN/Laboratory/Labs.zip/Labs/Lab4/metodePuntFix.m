function [ arrel, Xn] = metodePuntFix( f, g, x0, tol, M )
% M�tode de punt fix
% f �s la funci� inicial de la que volem aproximar el zero
% g �s la funci� transformada on passem a aproximar el punt fix
% x0 �s el punt inicial del m�tode
% tol �s la cota superior de l'error absolut
% M �s el m�xim d'iteracions permeses
    tolx = abs(x0);
    tolf = abs(f(x0));
    err = max(tolx, tolf);
    x = x0;
    k = 0;
    taula = [k, x, f(x0), tolx];
    while err > tol && k < M
        xPrev = x;
        x = g(x);
        k = k + 1;
        tolx = abs(x - xPrev);
        tolf = abs(f(x));
        taula = [taula;k, x, f(x), tolx];
        err = max(tolx, tolf);
    end
    disp('        k         x       tolf        tolx');
    fprintf('%2.0f \t %10.8f \t %10.6e \t %10.6e\n', taula')
    arrel = x;
    Xn = taula(:, 2);

end

