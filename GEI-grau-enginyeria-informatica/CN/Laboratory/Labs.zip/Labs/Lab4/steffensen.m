function [ alpha ] = steffensen(f, g, x0, tol, M )
% Acceleraci� de la converg�ncia mitjan�ant Steffensen
% f �s la funci� inicial de la que volem aproximar el zero
% g �s la funci� transformada on passem a aproximar el punt fix
% x0 �s el punt inicial del m�tode
% tol �s la cota superior de l'error absolut
% M �s el m�xim d'iteracions permeses
    k = 0;
    tolx = abs(x0);
    tolf = abs(f(x0));
    err = max(tolx, tolf);
    taula = [k, x0, f(x0), tolx];
    while err > tol && k < M
        xPrev = x0;
        x1 = g(x0);
        x2 = g(x1);
        k = k + 1;
        x0 = x0 - (x1 - x0)^2/(x2 -2*x1 + x0 + eps());
        tolx = abs(x0 - xPrev);
        tolf = abs(f(x0));
        err = max(tolx, tolf);
        taula = [taula;k, x0, f(x0), tolx];
    end
    disp('          k       xStef      tolx        tolf');
    fprintf('%2.0f \t %10.8f \t %10.6e \t %10.6e\n', taula')
    alpha = x0;
    
end