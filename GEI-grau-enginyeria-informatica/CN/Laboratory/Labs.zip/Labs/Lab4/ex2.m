%% Exercici 2
% Gr�fica
t = 0:0.05:2;
f = @(x) x.^6 - x - 1;
plot(t, f(t), t, zeros(size(t))), grid;
%% Localitzaci� mitjan�ant bisecci�
a = 1;
b = 1.4;
c = a + (b - a)/2;
valorF = [f(a), f(c), f(b)] 
l = (c - a)
%% Valor exacte
arrelExacte = fzero(f, 1)
%% M�tode iteratiu 1
g1 = @(x) x.^6 - 1;
dg1 = @(x) 6*x.^5;
x0 = c;
tol = 0.0005;
if abs(dg1(x0)) < 1
    [arrel] = metodePuntFix(f, g1, x0, tol, 50);
else
    disp('M�tode divergent');
end
%% M�tode iteratiu 2
g2 = @(x) (x + 1).^(1/6);
dg2 = @(x) 1./(x+1).^(5/6)/6;
x0 = c;
tol = 0.0005;
if abs(dg2(x0)) < 1
    [arrel] = metodePuntFix(f, g2, x0, tol, 50);
else
    disp('M�tode divergent');
end
%% Estudi de la converg�ncia
subplot(211);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg1(t), arrelExacte, dg1(arrelExacte), '*'), grid, title('M�tode 1');
subplot(212);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), 'c', t, dg2(t), arrelExacte, dg2(arrelExacte), '*'), grid, title('M�tode 2');