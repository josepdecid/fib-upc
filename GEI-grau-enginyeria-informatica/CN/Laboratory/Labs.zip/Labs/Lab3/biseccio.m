function [ arrel ] = biseccio( f, a, b, tol, N )
% M�tode de la bisecci�.
% Funci� f, interval [a,b] que cont� l'arrel
% N �s el m�xim d'iteracions permeses
% tol �s la cota superior de l'error absolut
    k = 0;
    tolx = abs(b - a);
    tolf = max(abs(f([a,b])));
    err = max(tolx, tolf);
    taula = [];
    while err > tol && k < N
        x = (a + b)/2;
        taula = [taula; k, a, x, b, f(x), tolx/2];
        if sign(f(x)) == sign(f(b))
            b = x;
        else
            a = x;
        end
        k = k + 1;
        tolx = abs(b - a);
        tolf = abs(f(x));
        err = max(tolx, tolf);
    end
    arrel = x;
    disp('  iter        a           x            b         tolf         tolx')
    fprintf('%2.0f \t %10.8f \t %10.8f \t %10.8f \t %10.8f \t %10.8f\n', taula')
end


