function [ arrel ] = secant(f,a,b,tol,M)
% M�tode de la secant
% Funci� f, interval [a,b] que cont� l'arrel
% N �s el m�xim d'iteracions permeses
% tol �s la cota superior de l'error absolut
    k = 0;
    tolx = abs(b-a);
    tolf = max(abs(f([a,b])));
    era = max(tolx,tolf);
    taula=[k, b, f(b), tolx];
    while (k<M && era>tol) 
        c = a;
        a = b;
        b = b + (b - c)/(f(c)/f(b)-1);
        k = k + 1;
        tolx = abs(b - a);
        tolf = max(abs(f(b)));
        era = max(tolx, tolf);
        taula = [taula; k, b, f(b), tolx];
    end
    arrel = b;
    disp('      iter         x         f(x)       tolx');
    fprintf('%2.0f \t %10.8f \t %10.6e \t %10.6e\n', taula')
end

