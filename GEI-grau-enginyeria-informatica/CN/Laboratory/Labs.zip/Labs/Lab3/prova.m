%% Symbolic

syms x
eqn = sin(x) == 1;
solx = solve(eqn,x)

t = -2*pi:0.1:2*pi;
plot(t, sin(t), t, solx, 1, '*', t ,ones(size(t)), pi, 0, '*', 'LineWidth', 2)

%%

syms f(x)
f(x) = sin(x^2);
df = diff(f,x)
t = -2*pi:0.1:2*pi;
plot(t, f(t))