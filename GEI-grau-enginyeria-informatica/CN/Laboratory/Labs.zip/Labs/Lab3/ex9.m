%% Exercici 9
f = @(x) x - cos(x);
t = -5:0.05:5;
plot(t, f(t), t, zeros(size(t))), grid;
%% Interval amb Bolzano
a = 0.5;
b = 1;
fprintf('%s \t %6.4f\n', 'Interval [0.5, 1]:', f(a)*f(b));
%% Arrel exacte amb fzero();
arrelExacte = fzero(f, 0.5);
fprintf('%s \t %10.8f\n', 'Arrel exacte:', arrelExacte);
%% Apartat b)
x0 = 0;
g1 = @(x) (x + cos(x))/2;
g2 = @(x) (2*x + cos(x))/3;
tol = eps(); % Assegurar parar per iteracions
iter = 15;
arrel1 = metodePuntFix(f, g1, x0, tol, iter);
fprintf('%s \t %10.8f\n', 'Arrel aprox:', arrel1);
fprintf('%s \t %10.6e\n', 'Error abs:', abs(arrelExacte - arrel1));
arrel2 = metodePuntFix(f, g2, x0, tol, iter);
fprintf('%s \t %10.8f\n', 'Arrel aprox:', arrel2);
%% Apartat c)
x0 = 1;
g3 = @(x) cos(x);
g4 = @(x) (x*cos(x))^(1/2);
tol = eps(); % Assegurar parar per iteracions
iter = 15;
arrel3 = metodePuntFix(f, g3, x0, tol, iter);
fprintf('%s \t %10.8f\n', 'Arrel aprox:', arrel3);
fprintf('%s \t %10.6e\n', 'Error abs:', abs(arrelExacte - arrel3));
arrel4 = metodePuntFix(f, g4, x0, tol, iter);
fprintf('%s \t %10.8f\n', 'Arrel aprox:', arrel4);
fprintf('%s \t %10.6e\n', 'Error abs:', abs(arrelExacte - arrel4));
%% Estudi de converg�ncia
t = 0:0.05:1;
dg1 = @(x) (1 - sin(x))/2;
dg2 = @(x) (2 - sin(x))/3;
dg3 = @(x) -sin(x);
dg4 = @(x) (cos(x) - x.*sin(x))./(2*(x.*cos(x)).^(1/2));
subplot(221);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), ...
    'c', t, dg1(t), arrelExacte, ... 
    dg1(arrelExacte), '*'), grid, title('M�tode 1');
subplot(222);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), ...
    'c', t, dg2(t), arrelExacte, ... 
    dg2(arrelExacte), '*'), grid, title('M�tode 2');
subplot(223);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), ...
    'c', t, dg3(t), arrelExacte, ... 
    dg3(arrelExacte), '*'), grid, title('M�tode 3');
subplot(224);
plot(t, -ones(size(t)), 'c', t, ones(size(t)), ...
    'c', t, dg4(t), arrelExacte, ... 
    dg4(arrelExacte), '*'), grid, title('M�tode 4');