function [ arrel ] = newton(f,df,x0,tol,M)
% M�tode de Newton
% Funci� f, punt x0 prop de l'arrel
% M �s el m�xim d'iteracions permeses
% tol �s la cota superior de l'error absolut
    k = 0; 
    x = x0;
    tolx = abs(x);
    tolf = (abs(f(x)));
    era = max(tolx, tolf);
    taula = [k, x, f(x), tolx];
    while (k < M && era > tol)
        y = f(x); z = df(x); s = y/z;
        x = x-s;
        k = k + 1;
        tolx = abs(s);
        tolf = max(abs(f(x)));
        era = max(tolx,tolf);
        taula = [taula; k, x, f(x), tolx];   
    end
    arrel = x;
    disp('     iter           x           f(x)      tolx'); 
    fprintf('%2.0f \t %10.8f \t %10.6e \t %10.6e\n', taula')
end
