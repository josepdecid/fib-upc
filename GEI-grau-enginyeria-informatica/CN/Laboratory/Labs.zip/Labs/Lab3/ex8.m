%% Exercici 7 - full problemes
%%Gr�fica
t = -2:0.05:2;
f = @(x) exp(x) - 2 + x;
df = @(x) exp(x) + 1;
plot(t, f(t), t, zeros(size(t))), grid;
%% fzero de Matlab
zero = fzero(f, 0)
%% M�tode de Newton
a = 0;
tol = 0.0005;
root =  newton(f, df, a, tol, 5)
%% M�tode de la Secant
a = 0;
b = 1;
tol = 0.0005;
root =  secant(f, a, b, tol, 5)
%% M�tode de la Bisecci�
a = 0;
b = 1;
tol = 0.0005;
root =  biseccio(f, a, b, tol, 25) % No volem que pari per iteracions