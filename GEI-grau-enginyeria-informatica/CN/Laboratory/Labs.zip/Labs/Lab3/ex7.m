%% Exercici 7
% Gr�fica
x = -4:0.05:4;
f = @(x) x.^3 - x - 1;
df = @(x) 3*x^2 - 1;
plot(x, f(x), x, zeros(size(x))), grid;
% Entre 1 i 2 veiem que hi ha un zero de la funci�
%% Utilitzant fzero()
root = fzero(f, 1.0)
%% M�tode de la bisecci�
tol = 0.001;
a = 1.0;
b = 2.0;
root = new_bisec(f, a, b, tol, 50)
%% M�tode de regula falsi
tol = 0.00005;
a = 1.0;
b = 2.0;
root = regulafalsi(f, a, b, tol, 50)
%% M�tode de Newton
tol = 0.00005;
a = 1.0;
root = newton(f, df, a, tol, 50)
%% M�tode de la secant
tol = 0.00005;
a = 1.0;
b = 2.0;
root = secant(f, a, b, tol, 50)