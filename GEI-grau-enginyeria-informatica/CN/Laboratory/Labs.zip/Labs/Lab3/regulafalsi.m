function [ arrel , taula ] = regulafalsi(f, a, b, tol, M)
%M�tode de la bisecci�
%   f: function, a:dada, b:dada, opci� f(a)*f(b)<0,
%   epsilon: cota error, M:cota iteracions
    k = 0;
    tolx = abs(b - a);
    tolf = max(abs(f([a, b])));
    era = max(tolx, tolf);
    taula=[];
    x = 0;
    while (k < M && era > tol)
        xPrev = x;
        x = b - f(b)*(b - a)./(f(b) - f(a));
        taula = [taula; k, a, c, b, f(x), tolx];
        if sign(f(b)) == sign(f(x))
            b = x;
        else
            a = x;
        end
        k = k + 1;
        tolf = abs(f(x));
        tolx = abs(x - xPrev);
        era = max(tolx, tolf);
        %tolx=min([abs(c-a),abs(b-c)]);
    end
    arrel = x;
    disp(' iter    a    x    b   f(x)   tolx');
    fprintf('%2.0f \t %10.8f \t %10.8f \t %10.8f \t %10.8f \t %10.8f\n', taula');
end