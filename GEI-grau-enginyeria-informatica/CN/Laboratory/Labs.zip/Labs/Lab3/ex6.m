%% Exercici 3 - full problemes
%%Gr�fica
t = -2:0.05:1.4;
f = @(x) x.^6 - x - 1;
df = @(x) 6*(x.^5) - 1;
%plot(t, t.^6, t, t + 1);
%plot(t, f(t)), grid
plot(t, f(t), t, zeros(size(t))), grid;
%% fzero de Matlab
zero = fzero(f, 1.2);
%% M�tode de Newton
a = 1.2;
tol = eps;
root =  newton(f, df, a, tol, 5)
%% M�tode de la Secant
a = 1.2;
b = 2;
tol = eps;
root =  secant(f, a, b, tol, 5)
%% M�tode de la Bisecci�
a = 1.0;
b = 2;
tol = eps;
root =  biseccio(f, a, b, tol, 5)