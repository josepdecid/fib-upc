%% Exemples de canvi en la escriptura dels nombres en Matlab
% format long, short, compact, ...
format short
x = 1/7000
%%
format long e
x
%%
format long g
x
%%
format rat
x

