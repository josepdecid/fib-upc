%% Exemple script errors
% error absolut, error relatiu i percent
x = input('valor x: ') %pi
y = input ('valor y: ')%22/7
%%
ea = abs(x - y);
disp('error absolut '), disp(ea)
%%
er = ea / abs(x)
disp('error relatiu '), disp(er)
%%
erp = er * 100
disp('error relatiu (%) '), disp(erp)