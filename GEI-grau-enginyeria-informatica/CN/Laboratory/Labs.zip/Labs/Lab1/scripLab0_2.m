%% Exemple de gr�fiques
% tres funcions en un mateix plot
x = 0:pi/20:2*pi;
y = sin(x);
z = sin(x - 0.25);
w = sin(x - 0.5);
plot(x, y, x, z, '--', x, w, ':')
title('gr�fica')
grid
