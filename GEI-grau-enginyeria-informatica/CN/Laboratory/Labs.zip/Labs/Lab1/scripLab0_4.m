%% Exemple de gr�fiques (3)
% dos gr�fics en una mateixa finestra
Ru = rand(10000, 1);
Rn = randn(10000, 1);
subplot(211);
hist(Ru, 50), title('uniforme')
subplot(212);
hist(Rn, 100), title('normal')