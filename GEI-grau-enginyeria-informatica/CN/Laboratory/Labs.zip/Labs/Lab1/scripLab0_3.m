%% Exemple de gr�fiques (2)
% tres funcions en un mateix plot
x = 0:pi/20:2*pi;
y = sin(x);
plot(x,y) 
%hold on
z = sin(x - 0.25);
pause(2);
plot(x, z, 'o')
w = sin(x - 0.5);
pause();
plot(x, w, '+')
%hold off