%% Escriure resultats
x = 0:0.1:1;
y = exp(x);
taula = [x; y]';
%% En un fitxer
fid = fopen('prova.txt', 'w');
fprintf(fid, '%6s %12s\n', 'x', 'exp(x)');
fprintf(fid, '%6.2f %12.8f\n', taula);
fclose(fid);
