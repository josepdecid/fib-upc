%% Exemple de gr�fiques (4)
% quatre gr�fics en una mateixa finestra
Ru = rand(10000, 1);
Rn = randn(10000, 1);
subplot(221);
plot(Ru), title('uniforme')
subplot(222);
hist(Ru, 100), title('uniforme')
subplot(223);
plot(Rn), title('normal')
subplot(224);
hist(Rn, 100), title('normal')