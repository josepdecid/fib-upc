function [ ea, er, erp ] = exempleErrors( x, y )
% Exemple funci� d'error
    ea = abs(x - y);
    er = ea / abs(x);
    erp = er * 100;
end

